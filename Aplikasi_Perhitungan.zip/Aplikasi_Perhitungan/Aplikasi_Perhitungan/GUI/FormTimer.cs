﻿using System;
using System.Windows.Forms;

namespace Aplikasi_Perhitungan.GUI
{
    public partial class FormTimer : Form
    {
        private int totalSeconds; 

        public FormTimer()
        {
            InitializeComponent();
            timerCountdown.Interval = 1000;
            timerCountdown.Tick += timerCountdown_Tick_1; 
        }

        private void textBoxMenit_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBoxMenit.Text, out _))
            {
                textBoxMenit.Text = "0";
            }
        }

        private void textBoxDetik_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBoxDetik.Text, out _))
            {
                textBoxDetik.Text = "0";
            }
        }

        private void buttonStart2_Click(object sender, EventArgs e)
        {
            int menit, detik;

            if (int.TryParse(textBoxMenit.Text, out menit) && int.TryParse(textBoxDetik.Text, out detik))
            {
                totalSeconds = (menit * 60) + detik;

                if (totalSeconds > 0)
                {
                    MessageBox.Show("Timer dimulai! Total detik: " + totalSeconds); 

                    UpdateLabelTimer();
                    timerCountdown.Enabled = true;
                    timerCountdown.Start();
                }
            }
            else
            {
                MessageBox.Show("Masukkan angka valid untuk menit dan detik.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonStop2_Click(object sender, EventArgs e)
        {
            timerCountdown.Stop();
        }

        private void buttonReset3_Click(object sender, EventArgs e)
        {
            timerCountdown.Stop();
            totalSeconds = 0;
            labelCount.Text = "00:00";
            textBoxMenit.Text = "0";
            textBoxDetik.Text = "0";
        }

        private void timerCountdown_Tick_1(object sender, EventArgs e)
        {
            MessageBox.Show("Timer Tick! Total detik: " + totalSeconds); 

            if (totalSeconds > 0)
            {
                totalSeconds--;
                UpdateLabelTimer();
            }
            else
            {
                timerCountdown.Stop();
                MessageBox.Show("Waktu Habis!", "Timer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void UpdateLabelTimer()
        {
            int menit = totalSeconds / 60;
            int detik = totalSeconds % 60;
            labelCount.Text = menit.ToString("00") + ":" + detik.ToString("00");
        }
    }
}
